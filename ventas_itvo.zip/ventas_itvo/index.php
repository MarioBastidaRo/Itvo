<!DOCTYPE html>
<html>
<head>

<title>Ventas ITVO</title>

<link rel="stylesheet" href="css/estilos.css">

</head>

<body>

<div class="container">

<h2>Sistema de Ventas ITVO</h2>

<form action="validar_login.php" method="POST">

<input type="text" name="usuario" placeholder="Usuario" required>

<input type="password" name="password" placeholder="Contraseña" required>

<button type="submit">Ingresar</button>

</form>

</div>

</body>
</html>
