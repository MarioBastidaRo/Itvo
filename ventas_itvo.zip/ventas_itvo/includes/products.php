<?php

// Mínima implementación "persistente" 

function getProducts() {
    $file = __DIR__ . '/../data/products.json';
    if (!file_exists($file)) {
        return [];
    }

    $json = file_get_contents($file);
    $productos = json_decode($json, true);
    return is_array($productos) ? $productos : [];
}

function saveProducts(array $productos) {
    $file = __DIR__ . '/../data/products.json';
    // Guarda el JSON con formato legible
    file_put_contents($file, json_encode($productos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function addProduct(string $nombre, float $precio, string $descripcion = '') {
    $productos = getProducts();

    // Determina el ID siguiente 
    $ultimoId = 0;
    foreach ($productos as $p) {
        if (isset($p['id']) && $p['id'] > $ultimoId) {
            $ultimoId = $p['id'];
        }
    }

    $productos[] = [
        'id' => $ultimoId + 1,
        'nombre' => $nombre,
        'precio' => $precio,
        'descripcion' => $descripcion,
    ];

    saveProducts($productos);
}

function findProductById($id) {
    $productos = getProducts();
    foreach ($productos as $p) {
        if (isset($p['id']) && $p['id'] == $id) {
            return $p;
        }
    }

    return null;
}
