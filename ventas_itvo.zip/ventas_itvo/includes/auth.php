<?php

// Esta librería se incluye en cada dashboard para asegurar que solo usuarios autenticados accedan
session_start();

// Si no hay usuario en sesión, redirige al login
if (!isset($_SESSION["usuario"])) {
    header("Location: ../index.php");
    exit;
}

?>