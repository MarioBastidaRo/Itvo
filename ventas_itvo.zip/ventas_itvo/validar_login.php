<?php

// Inicia la sesión 
session_start();

// Usuarios "simulados" 
$usuarios = [

    [
        "usuario" => "admin",
        "password" => "Admin123!",
        "tipo" => "admin"
    ],

    [
        "usuario" => "vendedor",
        "password" => "Vendedor123!",
        "tipo" => "vendedor"
    ],

    [
        "usuario" => "cliente",
        "password" => "Cliente123!",
        "tipo" => "cliente"
    ]

];

// Recibe valores del formulario de login
$usuario = $_POST["usuario"];
$password = $_POST["password"];

// Validación de contraseña según reglas solicitadas
$regex = "/^[A-Z](?=.*[a-z])(?=.*[0-9])(?=.*[\W]).{7,}$/";

if (!preg_match($regex, $password)) {
    echo "La contraseña debe comenzar con mayúscula, tener minúscula, número y caracter especial (mínimo 8 caracteres).";
    exit();
}

// Comprueba que el usuario exista y la contraseña coincida
foreach ($usuarios as $u) {

    if ($u["usuario"] == $usuario && $u["password"] == $password) {
        // Guarda datos en sesión
        $_SESSION["usuario"] = $usuario;
        $_SESSION["tipo"] = $u["tipo"];
        // Carrito en sesión (sólo para cliente)
        $_SESSION["carrito"] = [];

        // Redirige según el tipo de usuario
        if ($u["tipo"] == "admin") {
            header("Location: dashboards/admin.php");
        }

        if ($u["tipo"] == "vendedor") {
            header("Location: dashboards/vendedor.php");
        }

        if ($u["tipo"] == "cliente") {
            header("Location: dashboards/cliente.php");
        }

        exit();
    }
}

// Si no se encontró el usuario, muestra error simple
echo "Usuario o contraseña incorrectos";

?>