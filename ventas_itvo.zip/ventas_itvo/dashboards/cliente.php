<?php
include("../includes/auth.php");

// Solo el rol "cliente" puede acceder a esta página
if (!isset($_SESSION["tipo"]) || $_SESSION["tipo"] !== "cliente") {
    header("Location: ../index.php");
    exit;
}

// Funciones de productos
include("../includes/products.php");

// Asegura que exista el carrito en sesión
if (!isset($_SESSION["carrito"])) {
    $_SESSION["carrito"] = [];
}

$mensaje = '';

// Agrega producto al carrito cuando el cliente lo solicita
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['producto_id'])) {
    $productoId = intval($_POST['producto_id']);
    $producto = findProductById($productoId);
    if ($producto) {
        $_SESSION['carrito'][] = $producto;
        $mensaje = "Producto agregado al carrito.";
    } else {
        $mensaje = "Producto no encontrado.";
    }
}

// Obtener listado de productos y calcular total del carrito
$productos = getProducts();
$total = 0;
foreach ($_SESSION['carrito'] as $item) {
    $total += floatval($item['precio'] ?? 0);
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Cliente</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="dashboard">

<h2>Panel Cliente</h2>

<p>Bienvenido <?php echo $_SESSION["usuario"]; ?></p>

<?php if ($mensaje !== '') : ?>
    <div class="alert"><?php echo htmlspecialchars($mensaje); ?></div>
<?php endif; ?>

<div class="menu">

<div class="card">
<h3>Productos disponibles</h3>
<table class="table">
    <thead>
        <tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Acción</th></tr>
    </thead>
    <tbody>
        <?php // Muestra los productos que se pueden agregar al carrito ?>
        <?php foreach ($productos as $p) : ?>
            <tr>
                <td><?php echo $p['id']; ?></td>
                <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                <td>$<?php echo number_format($p['precio'], 2); ?></td>
                <td>
                    <form method="POST" style="margin:0;">
                        <input type="hidden" name="producto_id" value="<?php echo $p['id']; ?>">
                        <button type="submit">Agregar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

<div class="card">
<h3>Carrito</h3>
<?php if (count($_SESSION['carrito']) === 0) : ?>
    <p>No hay productos en el carrito.</p>
<?php else : ?>
    <table class="table">
        <thead>
            <tr><th>Nombre</th><th>Precio</th></tr>
        </thead>
        <tbody>
            <?php foreach ($_SESSION['carrito'] as $item) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['nombre']); ?></td>
                    <td>$<?php echo number_format($item['precio'], 2); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Total</th>
                <th>$<?php echo number_format($total, 2); ?></th>
            </tr>
        </tfoot>
    </table>
<?php endif; ?>
</div>

</div>

<a class="logout" href="../logout.php">Cerrar sesión</a>

</div>

</body>
</html>