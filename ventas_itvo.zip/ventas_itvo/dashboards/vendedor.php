<?php
include("../includes/auth.php");

// Solo el rol "vendedor" puede acceder a esta página
if (!isset($_SESSION["tipo"]) || $_SESSION["tipo"] !== "vendedor") {
    header("Location: ../index.php");
    exit;
}

// Funciones de productos (JSON simple)
include("../includes/products.php");

$mensaje = '';

// Procesa el formulario de agregar producto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre']) && isset($_POST['precio'])) {
    $nombre = trim($_POST['nombre']);
    $precio = floatval($_POST['precio']);
    $descripcion = trim($_POST['descripcion'] ?? '');

    if ($nombre !== '' && $precio > 0) {
        addProduct($nombre, $precio, $descripcion);
        $mensaje = "Producto agregado correctamente.";
    } else {
        $mensaje = "Completa el nombre y precio válido para el producto.";
    }
}

// Carga los productos para mostrarlos en la tabla
$productos = getProducts();
?>

<!DOCTYPE html>
<html>
<head>

<title>Vendedor</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="dashboard">

<h2>Panel Vendedor</h2>

<p>Bienvenido <?php echo $_SESSION["usuario"]; ?></p>

<?php if ($mensaje !== '') : ?>
    <div class="alert"><?php echo htmlspecialchars($mensaje); ?></div>
<?php endif; ?>

<div class="menu">

<div class="card">
<h3>Agregar producto</h3>
<form method="POST" action="">
    <label>Nombre</label>
    <input type="text" name="nombre" required>
    <label>Precio</label>
    <input type="number" step="0.01" name="precio" required>
    <label>Descripción</label>
    <input type="text" name="descripcion">
    <button type="submit">Agregar</button>
</form>
</div>

<div class="card">
<h3>Productos disponibles</h3>
<table class="table">
    <thead>
        <tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Descripción</th></tr>
    </thead>
    <tbody>
        <?php // Mostrar los productos disponibles ?>
        <?php foreach ($productos as $p) : ?>
            <tr>
                <td><?php echo $p['id']; ?></td>
                <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                <td>$<?php echo number_format($p['precio'], 2); ?></td>
                <td><?php echo htmlspecialchars($p['descripcion']); ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

</div>

<a class="logout" href="../logout.php">Cerrar sesión</a>

</div>

</body>
</html>