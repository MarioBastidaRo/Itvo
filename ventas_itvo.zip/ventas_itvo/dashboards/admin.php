<?php
include("../includes/auth.php");

// Validación de rol: sólo admin puede acceder a esta página
if (!isset($_SESSION["tipo"]) || $_SESSION["tipo"] !== "admin") {
    header("Location: ../index.php");
    exit;
}

// Carga de funciones para productos (JSON simple)
include("../includes/products.php");

// Lista de usuarios (simulada como "tabla")
$usuarios = [
    ["usuario" => "admin", "tipo" => "admin"],
    ["usuario" => "vendedor", "tipo" => "vendedor"],
    ["usuario" => "cliente", "tipo" => "cliente"],
];

$productos = getProducts();
?>

<!DOCTYPE html>
<html>
<head>

<title>Administrador</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="dashboard">

<h2>Panel Administrador</h2>

<p>Bienvenido <?php echo $_SESSION["usuario"]; ?></p>

<div class="menu">

<div class="card">
<h3>Productos</h3>
<p>Administrar componentes de computadoras</p>
<table class="table">
    <thead>
        <tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Descripción</th></tr>
    </thead>
    <tbody>
        <?php // Lista productos desde JSON para mostrar en tabla ?>
        <?php foreach ($productos as $p) : ?>
            <tr>
                <td><?php echo $p['id']; ?></td>
                <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                <td>$<?php echo number_format($p['precio'], 2); ?></td>
                <td><?php echo htmlspecialchars($p['descripcion']); ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

<div class="card">
<h3>Usuarios</h3>
<p>Gestionar vendedores y clientes</p>
<table class="table">
    <thead>
        <tr><th>Usuario</th><th>Tipo</th></tr>
    </thead>
    <tbody>
        <?php foreach ($usuarios as $u) : ?>
            <tr>
                <td><?php echo htmlspecialchars($u['usuario']); ?></td>
                <td><?php echo htmlspecialchars($u['tipo']); ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

</div>

<a class="logout" href="../logout.php">Cerrar sesión</a>

</div>

</body>
</html>